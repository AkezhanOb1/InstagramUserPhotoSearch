import {StyleSheet } from 'react-native'

const GalleryStyle = StyleSheet.create({

    wrapper: {
        flex: 1,
        display: 'flex',
        flexDirection: 'row',
        justifyContent: 'center',
        flexWrap: "wrap"
    },




})

export default GalleryStyle